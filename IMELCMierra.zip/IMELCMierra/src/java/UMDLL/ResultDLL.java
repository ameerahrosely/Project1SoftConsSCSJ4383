package UMDLL;

import static UMDLL.DBConnection.OpenConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ResultDLL {

    public ResultSet getAllResult() {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try {
            //Statement stmt = conn.createStatement();
            String sql = "SELECT* FROM RESULT";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery(sql);

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return rs;
    }

    public ResultSet getResultbyClass(String c) {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try {

            //Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM RESULT WHERE className=? ";

            PreparedStatement pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, c);
            rs = pstmt.executeQuery();

        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return rs;
    }

    public void saveMark(String m, String c, String id, String cname) {
        Connection conn = OpenConnection();
        if (c.equals("1")) {
            try {
                String sql = "INSERT INTO result " + "(studentID, className, C001)"
                        + " values(?,?,?)";

                PreparedStatement pstmt = conn.prepareStatement(sql);

                pstmt.setString(1, id);
                pstmt.setString(2, cname);
                pstmt.setInt(3, Integer.parseInt(m));

                pstmt.executeUpdate();

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        if (c.equals("3")) {
            try {
                String sql = "UPDATE result" + " SET C003 =?"
                        + " WHERE studentID=?";

                PreparedStatement pstmt = conn.prepareStatement(sql);

                pstmt.setInt(1, Integer.parseInt(m));
                pstmt.setString(2, id);
                pstmt.executeUpdate();

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
        
        if (c.equals("4")) {
            try {
                String sql = "UPDATE result" + " SET C004 =?"
                        + " WHERE studentID=?";

                PreparedStatement pstmt = conn.prepareStatement(sql);

                pstmt.setInt(1, Integer.parseInt(m));
                pstmt.setString(2, id);
                pstmt.executeUpdate();

            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }

    }
    
    public ResultSet getResultbyID(String studentID)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT * FROM RESULT WHERE studentID=? ";
        
        PreparedStatement pstmt = conn.prepareStatement(sql);
        pstmt.setString(1, studentID);
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
    

}
