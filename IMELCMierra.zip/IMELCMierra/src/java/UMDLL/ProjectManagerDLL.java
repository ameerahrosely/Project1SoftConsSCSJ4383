package UMDLL;

import static UMDLL.DBConnection.OpenConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class ProjectManagerDLL {
   
    
    public ResultSet getAllProjectManager()
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        String sql = "SELECT* FROM MANAGER ";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        rs = pstmt.executeQuery(sql);
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
}
