/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UMDLL;

import UMBLL.C1;
import UMBLL.C3;
import UMBLL.C4;
import UMBLL.StudentBLL;
import static UMDLL.DBConnection.OpenConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class StudentDLL {
    
    public ResultSet getAllStudent()
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT* FROM STUDENT";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        rs = pstmt.executeQuery(sql);
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
    
    public ResultSet getStudent(String id)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT * FROM STUDENT WHERE studentID = ?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, id);
        
        rs = pstmt.executeQuery();
        
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
    
     public ResultSet getStudentbyClass(String c)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT * FROM STUDENT WHERE className=?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, c);
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
     
     public ResultSet getStudentbyTeacher(String tcID)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT* FROM STUDENT WHERE teacherID = ?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, tcID);
        
        rs = pstmt.executeQuery();
        
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
     
     public void updateStudent(String id, StudentBLL s)
    {
        Connection conn = OpenConnection();
        try{
        
        //Statement stmt = conn.createStatement();
        
       String sql = "UPDATE STUDENT SET IC=?, studentID=? ,studentName=?, password=?, className=? WHERE studentID = ?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, s.getIc());
        pstmt.setString(2, s.getStudentID());
        pstmt.setString(3, s.getStudentName());
        pstmt.setString(4, s.getPassword());
        pstmt.setString(5, s.getClassName());
        pstmt.setString(6, id);
        
        pstmt.executeUpdate();
        
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
    }
     
     public void RegisterStudent(StudentBLL n)
    {
        Connection conn=OpenConnection();

      try{
        String sql="INSERT INTO STUDENT" +"(teacherID,studentName,IC,className,studentID,password,schoolName)"
                    +"values(?,?,?,?,?,?,?)";
        
        PreparedStatement pstmt=conn.prepareStatement(sql);
        
        pstmt.setString(1,n.getTeacherID());
        pstmt.setString(2, n.getStudentName());
        pstmt.setString(3,n.getIc());
        pstmt.setString(4,n.getClassName());
        pstmt.setString(5,n.getStudentID());
        pstmt.setString(6,n.getPassword());
        pstmt.setString(7,n.getSchoolName());
        
        pstmt.executeUpdate();
 
         }
        catch(Exception ex)
        {
            ex.printStackTrace();
        } 
    }
     
     public ResultSet getStudentbySchool(String schoolName)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT * FROM STUDENT WHERE schoolName=?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, schoolName);
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
    
     public void saveChallenge1(C1 n)
    {
        //call util to open connection
        Connection conn = OpenConnection();
        
        //use that conn object
        //create a statement
        try{
          
           //String sql="insert into c1(studentID,tv,fan,rice,pc,wash,peti,econ) values('"+studentID+"','"+tv+"','"+fan+"','"+rice+"','"+pc+"', '"+wash+"', '"+peti+"', '"+econ+"')";
           //String sql="INSERT INTO C1 (tv,fan,rice,pc,wash,peti,econ) value(?,?,?,?,?,?,?) where (studentID='username')";
           String sql="INSERT INTO c1 (tv,fan,rice,pc,wash,peti,econ,studentID) value(?,?,?,?,?,?,?,?)";
        
           PreparedStatement pstmt=conn.prepareStatement(sql);
        
        //step 5:execute a query
            pstmt.setString(1, n.getTv());
            pstmt.setString(2, n.getFan());
            pstmt.setString(3, n.getRice());
            pstmt.setString(4, n.getPc());
            pstmt.setString(5, n.getWash());
            pstmt.setString(6, n.getPeti());
            pstmt.setString(7, n.getEcon());
            pstmt.setString(8, n.getStudentID());
            pstmt.executeUpdate();
        //pstmt.close();
            
        //last step:close conncetion
            conn.close();
            
        }
        
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
     public ResultSet getChallenge1ByID(String ID)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT * FROM c1 WHERE studentID=?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, ID);
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
     
     public ResultSet getChallenge3ByID(String ID)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT * FROM c3 WHERE studentID=?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, ID);
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
     public ResultSet getChallenge4ByID(String ID)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT * FROM c4 WHERE studentID=?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, ID);
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
     
     
      public void saveChallenge4(C4 n)
    {
        //call util to open connection
        Connection conn = OpenConnection();
        
        //use that conn object
        //create a statement
        try{
           String sql="INSERT INTO c4 (recycle,pet,fsc,energy,circle,studentID) value(?,?,?,?,?,?)";
        
            PreparedStatement pstmt=conn.prepareStatement(sql);
        
        //step 5:execute a query
            pstmt.setString(1, n.getRecycle());
            pstmt.setString(2, n.getPet());
            pstmt.setString(3, n.getFsc());
            pstmt.setString(4, n.getEnergy());
            pstmt.setString(5, n.getCircle());
            pstmt.setString(6, n.getStudentID());
            pstmt.executeUpdate();
        //pstmt.close();
            
        //last step:close conncetion
            conn.close();
            
        }
        
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    public void saveChallenge3(C3 c)
    {
        //call util to open connection
        Connection conn = OpenConnection();
        
        //use that conn object
        //create a statement
        try{
           String sql="INSERT INTO c3 (date1,date2,start1,start2,end1,end2,distance1,distance2,TotalCarbon,recommend,studentID) "
                   + "value(?,?,?,?,?,?,?,?,?,?,?)";
        
            PreparedStatement pstmt=conn.prepareStatement(sql);
        
        //step 5:execute a query
            pstmt.setString(1,c.getDate1());
            pstmt.setString(2,c.getDate2());
            pstmt.setString(3, c.getStart1());
            pstmt.setString(4, c.getStart2());
            pstmt.setString(5, c.getEnd1());
            pstmt.setString(6, c.getEnd2());
            pstmt.setString(7, c.getDistance1());
            pstmt.setString(8, c.getDistance2());
            pstmt.setString(9, c.getTotalCarbon());
            pstmt.setString(10, c.getRecommend());
            pstmt.setString(11, c.getStudentID());
            
            pstmt.executeUpdate();
        //pstmt.close();
            
        //last step:close conncetion
            conn.close();
            
        }
        
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
    }
    
    public void deleteStudent(String studentID)
    {
        Connection conn = OpenConnection();
        try{
        
        //Statement stmt = conn.createStatement();
        
       String sql = "DELETE FROM STUDENT WHERE studentID = ?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, studentID);
        
        pstmt.executeUpdate();
        
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
    }
    
}
