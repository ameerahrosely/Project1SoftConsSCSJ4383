package UMDLL;

import UMBLL.TeacherBLL;
import static UMDLL.DBConnection.OpenConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class TeacherDLL {
    public ResultSet getAllTeacher()
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT* FROM TEACHER";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        rs = pstmt.executeQuery(sql);
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
    
    public ResultSet getTeacherbyID(String id)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        //Statement stmt = conn.createStatement();
        
        String sql = "SELECT* FROM TEACHER WHERE teacherID = ?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, id);
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
    
    public void updateTeacher(String id, TeacherBLL tc)
    {
        Connection conn = OpenConnection();
        try{
        
        //Statement stmt = conn.createStatement();
        
       String sql = "UPDATE TEACHER SET IC=?, teacherID=? ,fullname=?, password=?, schoolName=? WHERE teacherID = ?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, tc.getIC());
        pstmt.setString(2, tc.getTeacherID());
        pstmt.setString(3, tc.getFullName());
        pstmt.setString(4, tc.getPassword());
        pstmt.setString(5, tc.getSchoolName());
        pstmt.setString(6, id);
        
        pstmt.executeUpdate();
        
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
    }
    
    public void RegisterTeacher(TeacherBLL n)
    {
        Connection conn=OpenConnection();

      try{
        String sql="INSERT INTO TEACHER" +"(fullname,IC,schoolName,teacherID,password)"
                    +"values(?,?,?,?,?)";
        
        PreparedStatement pstmt=conn.prepareStatement(sql);
        
        pstmt.setString(1, n.getFullName());
        pstmt.setString(2,n.getIC());
        pstmt.setString(3,n.getSchoolName());
        pstmt.setString(4,n.getTeacherID());
        pstmt.setString(5,n.getPassword());
        
        pstmt.executeUpdate();
 
         }
        catch(Exception ex)
        {
            ex.printStackTrace();
        } 
    }
    
    public void deleteTeacher(String teacherID)
    {
        Connection conn = OpenConnection();
        try{
        
        //Statement stmt = conn.createStatement();
        
       String sql = "DELETE FROM TEACHER WHERE teacherID = ?";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, teacherID);
        
        pstmt.executeUpdate();
        
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
    }
    
}
