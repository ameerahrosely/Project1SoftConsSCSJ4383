package UMDLL;

import static UMDLL.DBConnection.OpenConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author user
 */
public class WorkbookDLL {
    
    public void updateStatus (String id, String t, String stat)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        String sql = "INSERT INTO workbookstatus (student,status,teacher) values (?,?,?) ";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, id);
        pstmt.setString(2, stat);
        pstmt.setString(3, t);
        
        pstmt.executeUpdate();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
    }
    
    public ResultSet alertbyTeacherID(String id)
    {
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        String sql = "SELECT * FROM workbookstatus WHERE teacher = ? ";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, id);
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
    public ResultSet getCompleteWB(String id){
        Connection conn = OpenConnection();
        ResultSet rs = null;
        try{
        
        String sql = "SELECT * FROM workbookstatus WHERE teacher = ? AND status = ? ";
        
        PreparedStatement pstmt = conn. prepareStatement(sql);
        pstmt.setString(1, id);
        pstmt.setString(2, "complete");
        rs = pstmt.executeQuery();
    
      }
        catch(Exception ex){
        ex.printStackTrace();
      }
        
        return rs;
    }
}
