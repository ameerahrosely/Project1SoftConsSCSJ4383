package WorkbookFulfillment;

import UMBLL.WorkbookBLL;
import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "submitWorkbook", urlPatterns = {"/submitWorkbook"})
public class submitWorkbook extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String id = request.getParameter("s");
        String t = request.getParameter("t");
        String stat = request.getParameter("status");
        
        WorkbookBLL wb = new WorkbookBLL();
        
        wb.updateData(id, t, stat);
        
        RequestDispatcher rd = request.getRequestDispatcher("User Management/workbookSubmitted.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>
}
