package WorkbookFulfillment;

import UMBLL.C4;
import UMBLL.StudentBLL;
import UMDLL.StudentDLL;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "c4", urlPatterns = {"/c4"})
public class c4 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException { 
        StudentDLL nu=new StudentDLL();
        C4 n=new C4();
    
     
        HttpSession session = request.getSession();
         StudentBLL s =(StudentBLL) session.getAttribute("student");
        
        System.out.println(s.getStudentID());
        
        n.setStudentID(s.getStudentID());
         n.setRecycle(request.getParameter("recycle"));
         n.setPet(request.getParameter("pet"));
         n.setFsc(request.getParameter("fsc"));
         n.setEnergy(request.getParameter("energy"));
         n.setCircle(request.getParameter("circle"));
         
         nu.saveChallenge4(n);
         
         response.sendRedirect("Workbook_Fulfillment/CompletingWorbook.jsp");
      
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
