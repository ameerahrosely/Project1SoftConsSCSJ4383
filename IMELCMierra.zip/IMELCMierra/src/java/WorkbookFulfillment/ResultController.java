package WorkbookFulfillment;

import UMBLL.ResultBLL;
import UMBLL.StudentBLL;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "ResultController", urlPatterns = {"/resultController"})
public class ResultController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            ResultBLL rbll = new ResultBLL();
            StudentBLL sbll = new StudentBLL();
            
            HttpSession sess = request.getSession();
            sbll = (StudentBLL)sess.getAttribute("student");
            
            ResultBLL rb = rbll.generateReportbyID(sbll.getStudentID());
            request.setAttribute("resultList", rb);
            RequestDispatcher rd = request.getRequestDispatcher("ReportGeneration/result.jsp");
            rd.include(request, response);
        }
    }
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
