/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package WorkbookFulfillment;

import UMBLL.C3;
import UMBLL.StudentBLL;
import UMDLL.StudentDLL;
import java.io.IOException;
import java.text.ParseException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "c3", urlPatterns = {"/c3"})
public class c3 extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ParseException {
        StudentDLL nu=new StudentDLL();
        C3 c=new C3();
    
     
        HttpSession session = request.getSession();
        StudentBLL s =(StudentBLL) session.getAttribute("student");
        
        System.out.println(s.getStudentID());
        
        c.setStudentID(s.getStudentID());
         c.setDate1(request.getParameter("date1"));
         c.setDate2(request.getParameter("date2"));
         c.setStart1(request.getParameter("start1"));
         c.setStart2(request.getParameter("start2"));
         c.setEnd1(request.getParameter("end1"));
         c.setEnd2(request.getParameter("end2"));
         c.setDistance1(request.getParameter("distance1"));
         c.setDistance2(request.getParameter("distance2"));
         c.setTotalCarbon(request.getParameter("TotalCarbon"));
         c.setRecommend(request.getParameter("recommend"));
        
         nu.saveChallenge3(c);
         
         response.sendRedirect("Workbook_Fulfillment/CompletingWorbook.jsp");
      
        
    }


    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(c3.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ParseException ex) {
            Logger.getLogger(c3.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }

}
