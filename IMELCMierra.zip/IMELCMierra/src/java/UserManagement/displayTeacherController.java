package UserManagement;

import UMBLL.TeacherBLL;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "displayTeacherController", urlPatterns = {"/displayTeacher"})
public class displayTeacherController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        TeacherBLL tc = new TeacherBLL();
        List <TeacherBLL> tclist = new ArrayList<>();
        
        tclist=tc.getAllTeacher();
        
        request.setAttribute("tclist", tclist);
        
        RequestDispatcher rd = request.getRequestDispatcher("User Management/displayTeacher.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
