package UserManagement;

import UMBLL.ProjectManagerBLL;
import UMBLL.StudentBLL;
import UMBLL.TeacherBLL;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = {"/login"})
public class LoginController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (request.getParameter("user").equals("student")) {
            StudentBLL stdBLL = new StudentBLL();
            boolean in = stdBLL.login(request.getParameter("username"), request.getParameter("password"));
            System.out.println(in + " student");
            if(in==true){
            HttpSession sesi = request.getSession();
            sesi.setAttribute("student", stdBLL);
            response.sendRedirect("User Management/studentMainPage.jsp");
            }
            else
                response.sendRedirect("User Management/Login.jsp");
        } 
        
         else if (request.getParameter("user").equals("teacher")) {
            TeacherBLL tcBLL = new TeacherBLL();
            boolean in = tcBLL.login(request.getParameter("username"), request.getParameter("password"));
            System.out.println(in + " teacher" + tcBLL.getFullName());
            if(in==true){
            HttpSession sesi = request.getSession();
            sesi.setAttribute("teacher", tcBLL);
            response.sendRedirect(request.getContextPath()+"/checkCompleteWB");
            }
            
            else{
                response.sendRedirect("User Management/Login.jsp");
            }
        } 
         else {
            ProjectManagerBLL pmBLL = new ProjectManagerBLL();
            boolean in = pmBLL.login(request.getParameter("username"), request.getParameter("password"));
            System.out.println(in + " project");
            if(in==true){
            HttpSession sesi = request.getSession();
            sesi.setAttribute("manager", pmBLL);
            response.sendRedirect("User Management/projectManagerMainPage.jsp");}
            
            else{
                response.sendRedirect("User Management/Login.jsp");
            }
         }

    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
