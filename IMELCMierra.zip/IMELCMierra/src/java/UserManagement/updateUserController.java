package UserManagement;

import UMBLL.StudentBLL;
import UMBLL.TeacherBLL;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "updateUserController", urlPatterns = {"/updateUser"})
public class updateUserController extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if(request.getParameter("userupdate").equals("student"))
        {
        StudentBLL std = new StudentBLL();
        HttpSession sesi = request.getSession();
        StudentBLL stdbefore = (StudentBLL)sesi.getAttribute("student");
        
        std.updateStudent(stdbefore.getStudentID(), request.getParameter("id"),request.getParameter("name")
        ,request.getParameter("ic"),request.getParameter("class"),request.getParameter("pass"));
        
        response.sendRedirect(request.getContextPath()+"/displayStudent");
        }
        if(request.getParameter("userupdate").equals("teacher"))
        {
            TeacherBLL tc = new TeacherBLL();
            String id = request.getParameter("idbefore");
            
            tc.updateTeacher(id, request.getParameter("id"), request.getParameter("name")
                    ,request.getParameter("ic"), request.getParameter("school")
                    ,request.getParameter("pass"));

            
            response.sendRedirect(request.getContextPath()+"/displayTeacher");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
