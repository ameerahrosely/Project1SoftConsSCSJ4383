package UserManagement;

import UMBLL.StudentBLL;
import UMBLL.TeacherBLL;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(name = "getUpdate", urlPatterns = {"/getUpdate"})
public class getUpdate extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        if(request.getParameter("userupdate").equals("student"))
        {
            StudentBLL stdBLL = new StudentBLL();
            stdBLL.getStudentbyID(request.getParameter("stdID"));   
            HttpSession sesi = request.getSession();
            sesi.setAttribute("student", stdBLL);
            response.sendRedirect("User Management/updateStudent.jsp"); 
        }
        if(request.getParameter("userupdate").equals("teacher"))
        {
            TeacherBLL tcBLL = new TeacherBLL();
            tcBLL.getTeacherbyID(request.getParameter("tcID"));   
            HttpSession sesi = request.getSession();
            sesi.setAttribute("teacher", tcBLL);
            response.sendRedirect("User Management/updateTeacher.jsp"); 
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
