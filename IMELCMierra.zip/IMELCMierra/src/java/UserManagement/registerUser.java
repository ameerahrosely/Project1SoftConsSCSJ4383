package UserManagement;

import UMBLL.StudentBLL;
import UMBLL.TeacherBLL;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "registerUser", urlPatterns = {"/registerUser"})
public class registerUser extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if(request.getParameter("userregister").equals("student"))
        {
            StudentBLL stdbll = new StudentBLL();
        
            stdbll.RegisterStudent(request.getParameter("teacherID"),request.getParameter("name"), request.getParameter("ic")
                    , request.getParameter("class"), request.getParameter("username"),request.getParameter("password"), request.getParameter("scname"));
        
            response.sendRedirect("displayStudent");
        }
        if(request.getParameter("userregister").equals("teacher"))
        {
            TeacherBLL tcbll = new TeacherBLL();
        
            tcbll.RegisterTeacher(request.getParameter("name"), request.getParameter("ic"), 
                request.getParameter("school"),request.getParameter("username"),request.getParameter("password"));
            
            response.sendRedirect("displayTeacher");
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    @Override
    public String getServletInfo() {
        return "Short description";
    }
}
