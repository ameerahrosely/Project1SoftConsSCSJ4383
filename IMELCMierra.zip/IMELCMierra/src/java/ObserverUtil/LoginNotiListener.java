package ObserverUtil;

import UMBLL.WorkbookBLL;
import java.util.ArrayList;
import java.util.List;

public class LoginNotiListener {

    //@Override
    
}
