package ObserverUtil;

import UMBLL.WorkbookBLL;
import java.util.ArrayList;
import java.util.List;

public class Observer {
    //public abstract boolean checkChange(String id);
    
    public boolean checkChange(String id) {
        List<WorkbookBLL> alert = new ArrayList<>();
        WorkbookBLL wb = new WorkbookBLL(); 
        
        alert= wb.dataChanged(id);
        
        Boolean change= false;
        
        for(int i=0; i<alert.size(); i++)
        {
            if(alert.get(i).getStatus().equals("complete"))
            {
                change=true;
            }
        }
        return change;
    }
}
