
package FacadeBLL;


public class Challenge4BLL implements Challenge {

    @Override
    public Pages getLink() {
       Pages cp4 = new Pages("Workbook_Fulfillment/c4.jsp");
       return cp4;
    }
    
}
