
package FacadeBLL;


public class Challenge3BLL implements Challenge {

    @Override
    public Pages getLink() {
        Pages cp3 = new Pages("Workbook_Fulfillment/c3.jsp");
        return cp3;
    }
    
}
