
package FacadeBLL;


public class Challenge1BLL implements Challenge{

    @Override
    public Pages getLink() {
        Pages cp1 = new Pages("Workbook_Fulfillment/c1.jsp");
        return cp1;
    }
    
}
