
package FacadeBLL;

public class Pages {
    private String link;

    public Pages(String link) {
        this.link = link;
    }

    public Pages() {
    }
    
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
}
