
package FacadeBLL;


public interface Challenge {
    public Pages getLink();
}
