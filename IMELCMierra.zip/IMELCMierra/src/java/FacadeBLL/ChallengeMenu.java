
package FacadeBLL;


public class ChallengeMenu {
    public Pages getMenu1()
    {
        Challenge1BLL c1 = new Challenge1BLL();
        Pages cp1 = (Pages)c1.getLink();
        return cp1;   
    }
    
    public Pages getMenu3(){
        Challenge3BLL c3 = new Challenge3BLL();
        Pages cp3 = (Pages)c3.getLink();
        return cp3;
    }
    
    public Pages getMenu4(){
        Challenge4BLL c4 = new Challenge4BLL();
        Pages cp4 = (Pages)c4.getLink();
        return cp4; 
    }
}
