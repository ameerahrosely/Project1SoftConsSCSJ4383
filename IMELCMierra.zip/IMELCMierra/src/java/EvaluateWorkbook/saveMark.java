/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EvaluateWorkbook;

import UMBLL.ResultBLL;
import UMBLL.StudentBLL;
import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet(name = "saveMark", urlPatterns = {"/saveMark"})
public class saveMark extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if(request.getParameter("chal").equals("1"))
        {
            ResultBLL r = new ResultBLL();
            
            r.saveMark(request.getParameter("mark1"),request.getParameter("chal"),request.getParameter("id"),request.getParameter("class"));
            
            String schoolName = request.getParameter("schoolName");
            StudentBLL sbll = new StudentBLL();
            List<StudentBLL> sb = sbll.getStudentbySchool(schoolName);
            request.setAttribute("studentList", sb);
            
            RequestDispatcher rd = request.getRequestDispatcher("EvaluateWorkbook/studentList.jsp");
            rd.include(request,response);
        }
        if(request.getParameter("chal").equals("3"))
        {
            ResultBLL r = new ResultBLL();
            
            r.saveMark(request.getParameter("mark"),request.getParameter("chal"),request.getParameter("id"),request.getParameter("class"));
            
            String schoolName = request.getParameter("schoolName");
            StudentBLL sbll = new StudentBLL();
            List<StudentBLL> sb = sbll.getStudentbySchool(schoolName);
            request.setAttribute("studentList", sb);
            
            RequestDispatcher rd = request.getRequestDispatcher("EvaluateWorkbook/studentList.jsp");
            rd.include(request,response);
        }
        if(request.getParameter("chal").equals("4"))
        {
            ResultBLL r = new ResultBLL();
            
            r.saveMark(request.getParameter("mark"),request.getParameter("chal"),request.getParameter("id"),request.getParameter("class"));
            
            String schoolName = request.getParameter("schoolName");
            StudentBLL sbll = new StudentBLL();
            List<StudentBLL> sb = sbll.getStudentbySchool(schoolName);
            request.setAttribute("studentList", sb);
            
            RequestDispatcher rd = request.getRequestDispatcher("EvaluateWorkbook/studentList.jsp");
            rd.include(request,response);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
