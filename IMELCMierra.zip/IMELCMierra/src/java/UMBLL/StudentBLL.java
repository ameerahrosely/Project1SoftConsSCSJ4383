package UMBLL;

import UMDLL.StudentDLL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class StudentBLL {
    private String studentID;
    private String password;
    private String className;
    private String ic;
    private String studentName;
    private String teacherID;
    private String schoolName;

    public String getStudentID() {
        return studentID;
    }

    public String getPassword() {
        return password;
    }

    public String getClassName() {
        return className;
    }

    public String getIc() {
        return ic;
    }

    public String getStudentName() {
        return studentName;
    }

    public String getTeacherID() {
        return teacherID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public void setIc(String ic) {
        this.ic = ic;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public void setTeacherID(String teacherID) {
        this.teacherID = teacherID;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }

    public boolean login(String uname, String pass){
        StudentDLL stdll = new StudentDLL();
        boolean in = false;
        ResultSet rs = stdll.getAllStudent();
        try{
            while(rs.next())
            {
                if(uname.equals(rs.getString("studentID")) && pass.equals(rs.getString("password"))){
                   setStudentID(rs.getString("studentID"));
                   setPassword(rs.getString("password"));
                   setClassName(rs.getString("className"));
                   setIc(rs.getString("IC"));
                   setStudentName(rs.getString("studentName"));
                   setTeacherID(rs.getString("teacherID"));
                   setSchoolName(rs.getString("schoolName"));
                   in=true;
                }
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
        }
        return in;
    }
    
    public void getStudentbyID(String id){
        StudentDLL stdll = new StudentDLL();
        ResultSet rs = stdll.getStudent(id);
        try{
            while(rs.next())
            {
                setStudentID(rs.getString("studentID"));
                setPassword(rs.getString("password"));
                setClassName(rs.getString("className"));
                setIc(rs.getString("IC"));
                setStudentName(rs.getString("studentName"));
                setTeacherID(rs.getString("teacherID"));
                setSchoolName(rs.getString("schoolName"));
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
        }
    }
    
    public List<StudentBLL> getStudentbyTeacher(String tcID)
    {
        List <StudentBLL> stdlist = new ArrayList<>();
        StudentDLL stdll = new StudentDLL();
        
        ResultSet rs = stdll.getStudentbyTeacher(tcID) ;
        try{
        //populate/fetch the result
        while(rs.next()){
           
           StudentBLL s = new StudentBLL();
           s.setStudentID(rs.getString("studentID"));
           s.setStudentName(rs.getString("studentName"));
           s.setPassword(rs.getString("password"));
           s.setClassName(rs.getString("className"));
           s.setIc(rs.getString("IC"));
           s.setTeacherID(rs.getString("teacherID"));
           s.setSchoolName(rs.getString("schoolName"));
           stdlist.add(s);
        }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
      
      return stdlist;       
    }
    
    public void updateStudent(String idbefore, String id, String name, String ic, String klas, String pass){
        StudentDLL stdll = new StudentDLL();
        
        StudentBLL std  = new StudentBLL();
        
        std.setStudentID(id);
        std.setStudentName(name);
        std.setIc(ic);
        std.setClassName(klas);
        std.setPassword(pass);
        
        stdll.updateStudent(idbefore, std);
    }
    
    public void RegisterStudent(String tcid,String n,String ic,String cn,String uname,String pass, String scname)
    {
        StudentDLL stdll = new StudentDLL();
        StudentBLL a = new StudentBLL();
        
        
          try{
              
              a.setTeacherID(tcid);
              a.setStudentName(n);
              a.setIc(ic);
              a.setClassName(cn);
              a.setStudentID(uname);
              a.setPassword(pass);
              a.setSchoolName(scname);
  
             stdll.RegisterStudent(a);
        }
        catch(Exception ex){
        ex.printStackTrace();
        }
        }
    
    public List<StudentBLL> getStudentbyClass(String className){
        StudentDLL sdll = new StudentDLL();
        List <StudentBLL> sbll = new ArrayList<StudentBLL>();
        ResultSet rs = sdll.getStudentbyClass(className);
        try{
            while(rs.next())
            {
                StudentBLL stdb = new StudentBLL();
                stdb.setStudentID(rs.getString("studentID"));
                stdb.setStudentName(rs.getString("studentName"));
                stdb.setClassName(rs.getString("className"));
                sbll.add(stdb);
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
        }
        
        return sbll;
    }
    
    public List<StudentBLL> getStudentbySchool(String schoolName){
        StudentDLL sdll = new StudentDLL();
        List <StudentBLL> sbll = new ArrayList<StudentBLL>();
        ResultSet rs = sdll.getStudentbySchool(schoolName);
        try{
            while(rs.next())
            {
                StudentBLL stdb = new StudentBLL();
                stdb.setStudentID(rs.getString("studentID"));
                stdb.setStudentName(rs.getString("studentName"));
                stdb.setClassName(rs.getString("className"));
                stdb.setSchoolName(rs.getString("schoolName"));
                sbll.add(stdb);
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
        }
        
        return sbll;
    }
    
    // getC1byID 
    public void deleteStudent(String studentID){
        StudentDLL stdll = new StudentDLL();
        StudentBLL std  = new StudentBLL();
        stdll.deleteStudent(studentID);
    }
}
