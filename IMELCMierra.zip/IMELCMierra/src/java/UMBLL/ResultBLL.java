package UMBLL;

import UMDLL.ResultDLL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class ResultBLL {
    private int resultID;
    private String studentID;
    private String className;
    private int C001;
    private int C003;
    private int C004;
    
    //public ReportHandler m_ReportHandler;
    
    public int getResultID() {
        return resultID;
    }

    public void setResultID(int resultID) {
        this.resultID = resultID;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }

    public int getC001() {
        return C001;
    }

    public void setC001(int C001) {
        this.C001 = C001;
    }
    
    public int getC003() {
        return C003;
    }

    public void setC003(int C003) {
        this.C003 = C003;
    }

    public int getC004() {
        return C004;
    }

    public void setC004(int C004) {
        this.C004 = C004;
    }

    public void saveMark(String m , String c, String id, String cname){
        ResultDLL rd = new ResultDLL();
        
        rd.saveMark(m,c,id,cname);
    }

    public List<ResultBLL> generateReport(String className){
        ResultDLL rdll = new ResultDLL();
        List <ResultBLL> rbll = new ArrayList<>();
        ResultSet rs = rdll.getResultbyClass(className);
        try{
            while(rs.next())
            {
                ResultBLL res = new ResultBLL();
                res.setClassName(rs.getString("className"));
                res.setResultID (rs.getInt("resultID"));
                res.setStudentID (rs.getString("studentID"));
                res.setC001(rs.getInt("C001"));
                res.setC003(rs.getInt("C003"));
                res.setC004(rs.getInt("C004"));
                
                rbll.add(res);
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
        }
        
        return rbll;
    }
    
    public ResultBLL generateReportbyID(String studentID){
        ResultDLL rdll = new ResultDLL();
        ResultBLL res = new ResultBLL();
        ResultSet rs = rdll.getResultbyID(studentID);
        try{
            while(rs.next())
            {
                res.setClassName(rs.getString("className"));
                res.setStudentID (rs.getString("studentID"));
                res.setC001(rs.getInt("C001"));
                res.setC003(rs.getInt("C003"));
                res.setC004(rs.getInt("C004"));
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
        }
        
        return res;
    }
}
