package UMBLL;

import UMDLL.StudentDLL;
import java.sql.ResultSet;

public class C1 {  
 
private String studentID;
private String tv, fan, rice, pc, wash, peti, econ;

//generate getters and setters 


public String getStudentID() {
        return studentID;
    }

public String getTv() {
        return tv;
    }

public String getFan() {
        return fan;
    }

public String getRice() {
        return rice;
    }

public String getPc() {
        return pc;
    }

public String getWash() {
        return wash;
    }

public String getPeti() {
        return peti;
    }

public String getEcon() {
        return econ;
    }

public void setTv(String tv) {
        this.tv = tv;
    }

public void setFan(String fan) {
        this.fan = fan;
    }

public void setRice(String rice) {
        this.rice = rice;
    }

public void setPc(String pc) {
        this.pc = pc;
    }

public void setWash(String wash) {
        this.wash = wash;
    }

public void setPeti(String peti) {
        this.peti = peti;
    }

    public void setEcon(String econ) {
        this.econ = econ;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public boolean saveChallenge1(String parameter, String parameter0, String parameter1, String parameter2, String parameter3, String parameter4, String parameter5) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    public C1 getChallenge1ByID(String ID)
    {
        StudentDLL sdll = new StudentDLL();
        C1 c = new C1();
        ResultSet rs = sdll.getChallenge1ByID(ID);
        try{
            while(rs.next())
            {
               c.setEcon(rs.getString("econ"));
               c.setFan(rs.getString("fan"));
               c.setPc(rs.getString("pc"));
               c.setPeti(rs.getString("peti"));
               c.setRice(rs.getString("rice"));
               c.setTv(rs.getString("tv"));
               c.setWash(rs.getString("wash"));
               c.setStudentID(rs.getString("studentID"));
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
      }
        return c;
    }

}  
