package UMBLL;

import UMDLL.ProjectManagerDLL;
import java.sql.ResultSet;

public class ProjectManagerBLL {
    private String managerID;
    private String firstName;
    private String lastName;
    private String email;
    private String password;
    private String phone;

    public String getManagerID() {
        return managerID;
    }

    public void setManagerID(String managerID) {
        this.managerID = managerID;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
    
    public boolean login(String uname, String pass) {
        ProjectManagerDLL pmdll = new ProjectManagerDLL();
        boolean in = false;
        ResultSet rs = pmdll.getAllProjectManager();
        try {
            while (rs.next()) {
                if (uname.equals(rs.getString("managerID")) && pass.equals(rs.getString("password"))) {
                    setManagerID(rs.getString("managerID"));
                    setFirstName(rs.getString("firstName"));
                    setLastName(rs.getString("lastName"));
                    setEmail(rs.getString("email"));
                    setPhone(rs.getString("phoneNumber"));
                    setPassword(rs.getString("password"));
                    in = true;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return in;
    }
}
