/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UMBLL;

/**
 *
 * @author user
 */
public class UserIMELC {
    private String username;
    private String password;
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPass() {
        return password;
    }
    
    public void setPass(String password) {
        this.password = password;
    }
}
