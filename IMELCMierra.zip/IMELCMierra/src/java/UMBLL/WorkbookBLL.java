package UMBLL;

import UMDLL.WorkbookDLL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class WorkbookBLL {

    private String status;
    private String id;

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public void updateData(String id, String t, String stat) {
        WorkbookDLL wd = new WorkbookDLL();
        
        wd.updateStatus(id, t, stat);
    }

    public List<WorkbookBLL> dataChanged(String id) {
        List<WorkbookBLL> alert = new ArrayList<>();

        WorkbookDLL wd = new WorkbookDLL();
        ResultSet rs = wd.alertbyTeacherID(id);
        try {
            while (rs.next()) {
                WorkbookBLL w = new WorkbookBLL();
                w.setStatus(rs.getString("status"));
                w.setId(rs.getString("student"));

                alert.add(w);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return alert;
    }

    public List<WorkbookBLL> getCompleteWB(String id) {
        List<WorkbookBLL> wb = new ArrayList<>();

        WorkbookDLL wd = new WorkbookDLL();
        ResultSet rs = wd.getCompleteWB(id);
        try {
            while (rs.next()) {
                WorkbookBLL w = new WorkbookBLL();
                w.setStatus(rs.getString("status"));
                w.setId(rs.getString("student"));

                wb.add(w);
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        return wb;
    }

}
