package UMBLL;

import UMDLL.StudentDLL;
import java.sql.ResultSet;

public class C4 {
    
    private String studentID;
    private String recycle;
    private String pet;
    private String fsc;
    private String energy;
    private String circle;

   
    public String getStudentID() {
        return studentID;
    }

    public String getRecycle() {
        return recycle;
    }

    public String getPet() {
        return pet;
    }

    public String getFsc() {
        return fsc;
    }

    public String getEnergy() {
        return energy;
    }

    public String getCircle() {
        return circle;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public void setRecycle(String recycle) {
        this.recycle = recycle;
    }

    public void setPet(String pet) {
        this.pet = pet;
    }

    public void setFsc(String fsc) {
        this.fsc = fsc;
    }

    public void setEnergy(String energy) {
        this.energy = energy;
    }

    public void setCircle(String circle) {
        this.circle = circle;
    }
  
    public C4 getChallenge4ByID(String ID)
    {
        StudentDLL sdll = new StudentDLL();
        C4 c = new C4();
        ResultSet rs = sdll.getChallenge4ByID(ID);
        try{
            while(rs.next())
            {
               c.setRecycle(rs.getString("recycle"));
               c.setPet(rs.getString("pet"));
               c.setFsc(rs.getString("fsc"));
               c.setEnergy(rs.getString("energy"));
               c.setCircle(rs.getString("circle"));
               c.setStudentID(rs.getString("studentID"));
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
      }
        return c;
    }
}
