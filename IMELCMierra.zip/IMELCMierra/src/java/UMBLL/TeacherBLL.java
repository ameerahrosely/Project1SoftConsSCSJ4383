/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UMBLL;

import UMDLL.TeacherDLL;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class TeacherBLL {
        private String IC;
        private String teacherID;
        private String fullName;
        private String password;
        private String schoolName;

    public String getIC() {
        return IC;
    }

    public void setIC(String IC) {
        this.IC = IC;
    }

    public String getTeacherID() {
        return teacherID;
    }

    public void setTeacherID(String teacherID) {
        this.teacherID = teacherID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSchoolName() {
        return schoolName;
    }

    public void setSchoolName(String schoolName) {
        this.schoolName = schoolName;
    }
        
    public boolean login(String uname, String pass) {
        TeacherDLL tcdll = new TeacherDLL();
        boolean in = false;
        ResultSet rs = tcdll.getAllTeacher();
        try {
            while (rs.next()) {
                if (uname.equals(rs.getString("teacherID")) && pass.equals(rs.getString("password"))) {
                    setTeacherID(rs.getString("teacherID"));
                    setPassword(rs.getString("password"));
                    setIC(rs.getString("IC"));
                    setFullName(rs.getString("fullname"));
                    setSchoolName(rs.getString("schoolName"));
                    in = true;
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }

        return in;
    }
    
    public List<TeacherBLL> getAllTeacher()
    {
        List <TeacherBLL> tclist = new ArrayList<>();
        TeacherDLL tcdll = new TeacherDLL();
        
        ResultSet rs = tcdll.getAllTeacher();
        try{
        //populate/fetch the result
        while(rs.next()){
           
            TeacherBLL tc = new TeacherBLL();
            tc.setTeacherID(rs.getString("teacherID"));
            tc.setPassword(rs.getString("password"));
            tc.setIC(rs.getString("IC"));
            tc.setFullName(rs.getString("fullname"));
            tc.setSchoolName(rs.getString("schoolName"));
            tclist.add(tc);
        }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
      
      return tclist;       
    }
    
    public void getTeacherbyID(String id)
    {
        TeacherDLL tcdll = new TeacherDLL();
        
        ResultSet rs = tcdll.getTeacherbyID(id);
        try{
        //populate/fetch the result
        while(rs.next()){
           
            setTeacherID(rs.getString("teacherID"));
            setPassword(rs.getString("password"));
            setIC(rs.getString("IC"));
            setFullName(rs.getString("fullname"));
            setSchoolName(rs.getString("schoolName"));
        }
        }
        catch(Exception ex)
        {
            ex.printStackTrace();
        }
          
    }
    
    public void updateTeacher(String idbefore, String id, String name, String ic, String school, String pass){
        TeacherDLL tcdll = new TeacherDLL();
        
        TeacherBLL tc = new TeacherBLL();
        
        tc.setTeacherID(id);
        tc.setFullName(name);
        tc.setIC(ic);
        tc.setSchoolName(school);
        tc.setPassword(pass);
        
        tcdll.updateTeacher(idbefore, tc);
        
    }
    
    public void RegisterTeacher(String n,String ic,String sc,String uname,String pass)
    {
        TeacherDLL tcdll = new TeacherDLL();
        TeacherBLL a = new TeacherBLL();
        
        
          try{
              
              a.setFullName(n);
              a.setIC(ic);
              a.setSchoolName(sc);
              a.setTeacherID(uname);
              a.setPassword(pass);
  
             tcdll.RegisterTeacher(a);
        }
        catch(Exception ex){
        ex.printStackTrace();
        }
        }
    
     public void deleteTeacher(String teacherID){
        TeacherDLL teachdll = new TeacherDLL();
        TeacherBLL teach  = new TeacherBLL();
        
        
        teachdll.deleteTeacher(teacherID);
    }
}
