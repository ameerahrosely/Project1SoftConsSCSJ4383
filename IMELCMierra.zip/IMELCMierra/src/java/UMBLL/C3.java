/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package UMBLL;

import UMDLL.StudentDLL;
import java.sql.ResultSet;

public class C3 {
    private String date1;
    private String date2;
    private String start1;
    private String start2;
    private String end1;
    private String end2;
    private String distance1;
    private String distance2;
    private String TotalCarbon;
    private String recommend;
    private String studentID;

    public String getDate1() {
        return date1;
    }

    public String getDate2() {
        return date2;
    }

    public String getStart1() {
        return start1;
    }

    public String getStart2() {
        return start2;
    }

    public String getEnd1() {
        return end1;
    }

    public String getEnd2() {
        return end2;
    }

    public String getDistance1() {
        return distance1;
    }

    public String getDistance2() {
        return distance2;
    }

    public void setDate1(String date1) {
        this.date1 = date1;
    }

    public void setDate2(String date2) {
        this.date2 = date2;
    }

    public void setStart1(String start1) {
        this.start1 = start1;
    }

    public void setStart2(String start2) {
        this.start2 = start2;
    }

    public void setEnd1(String end1) {
        this.end1 = end1;
    }

    public void setEnd2(String end2) {
        this.end2 = end2;
    }

    public void setDistance1(String distance1) {
        this.distance1 = distance1;
    }

    public void setDistance2(String distance2) {
        this.distance2 = distance2;
    }

    public String getTotalCarbon() {
        return TotalCarbon;
    }

    public String getRecommend() {
        return recommend;
    }

    public void setTotalCarbon(String TotalCarbon) {
        this.TotalCarbon = TotalCarbon;
    }

    public void setRecommend(String recommend) {
        this.recommend = recommend;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }
 
    public C3 getChallenge3ByID(String ID)
    {
        StudentDLL sdll = new StudentDLL();
        C3 c = new C3();
        ResultSet rs = sdll.getChallenge3ByID(ID);
        try{
            while(rs.next())
            {
               c.setDate1(rs.getString("date1"));
               c.setDate2(rs.getString("date2"));
               c.setStart1(rs.getString("start1"));
               c.setStart2(rs.getString("start2"));
               c.setEnd1(rs.getString("end1"));
               c.setEnd2(rs.getString("end2"));
               c.setDistance1(rs.getString("distance1"));
               c.setDistance2(rs.getString("distance2"));
               c.setTotalCarbon(rs.getString("TotalCarbon"));
               c.setRecommend(rs.getString("recommend"));
               c.setStudentID(rs.getString("studentID"));
            }
        }
        catch(Exception ex){
        ex.printStackTrace();
      }
        return c;
    }
}
